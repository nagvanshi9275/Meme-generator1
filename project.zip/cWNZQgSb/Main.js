

import React from 'react'

import Dhoni from './Dhoni.js'
export default function Buddha(){
    
    
    const[vedant, om] = React.useState("")
    
    function Shakira(){
      
      const asar =   Dhoni.data.meme1
        
        const random = Math.floor(Math.random()* asar.length)
        
        om(asar[random].url)
        
        
    }
    
    
    
    
    
    
    
    
    
    return(
        
        <div className="mai">
        
        <button onClick={Shakira} className="bu">CLICK </button>
        
    
        <img className="sakshi" src={vedant} />
        
        </div>
        
        
    )
    
    
}




