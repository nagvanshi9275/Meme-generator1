import React from 'react';
import ReactDOM from 'react-dom/client';

import Ash from './Nav'

import Buddha from './Main'

function App() {
  return (
    <div>
    
    
    <Ash/>
    
    <Buddha/>
    
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />); 