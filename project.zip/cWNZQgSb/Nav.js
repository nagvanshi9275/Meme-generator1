


import React from 'react'



export default function Ash(){
    
    return(
        
       <div>
       
       <nav className="nav">
       
       <img className="pic" src="https://i.imgflip.com/30b1gx.jpg"/>
       
       <h4>MEME GENERATOR</h4>
       
       </nav>
       
       </div> 
        
        
        
    )
    
    
    
    
}







